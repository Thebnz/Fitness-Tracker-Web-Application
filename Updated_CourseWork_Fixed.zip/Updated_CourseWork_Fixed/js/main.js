
const users = [
    { username: "john", password: "1234", weight: 70, height: 1.75, goalWeight: 65 },
    { username: "mary", password: "abcd", weight: 60, height: 1.65, goalWeight: 58 }
];

function login(username, password) {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('currentUser', JSON.stringify(user));
        window.location.href = 'profile.html';
    } else {
        alert('Invalid credentials');
    }
}

function checkLogin() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (isLoggedIn !== 'true') {
        alert('You are not logged in, Please login');
        window.location.href = 'login.html';
    }
}

function showUserStats() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    if (user) {
        document.getElementById('username').innerText = user.username;
        document.getElementById('weight').innerText = user.weight + ' kg';
        document.getElementById('height').innerText = user.height + ' m';
        document.getElementById('goalWeight').innerText = user.goalWeight + ' kg';
    }
}

function calculateBMI(weight, height) {
    return (weight / (height * height)).toFixed(2);
}

function showBMI() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    if (user) {
        const bmi = calculateBMI(user.weight, user.height);
        document.getElementById('bmi').innerText = 'Your BMI: ' + bmi;
    }
}

function calculateCalories(steps) {
    return (steps * 0.04).toFixed(2);
}

function handleStepsInput() {
    const steps = parseInt(document.getElementById('dailySteps').value);
    const calories = calculateCalories(steps);
    document.getElementById('caloriesBurned').innerText = 'Calories burned: ' + calories + ' kcal';
}

function calculateCalorieAdjustment() {
    const user = JSON.parse(localStorage.getItem('currentUser'));
    const current = user.weight;
    const goal = user.goalWeight;
    const diff = goal - current;
    const totalCal = diff * 7700;
    const dailyCal = totalCal / 30;

    if (diff > 0) {
        document.getElementById('calorieAdvice').innerText =
            'You need a daily surplus of ' + dailyCal.toFixed(0) + ' kcal to reach your goal.';
    } else if (diff < 0) {
        document.getElementById('calorieAdvice').innerText =
            'You need a daily deficit of ' + Math.abs(dailyCal.toFixed(0)) + ' kcal to reach your goal.';
    } else {
        document.getElementById('calorieAdvice').innerText = 'You are at your goal weight!';
    }
}

window.onload = function() {
    checkLogin();
    showUserStats();
    showBMI();
    calculateCalorieAdjustment();
};
