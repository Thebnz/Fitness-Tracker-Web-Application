

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());

let users = {
  "12345": {
    name: "John Doe",
    age: 28,
    gender: "male",
    height_cm: 180,
    weight_kg: 75,
    goal: "Lose fat and build lean muscle",
    recentWorkouts: []
  }
};

// GET profile
app.get('/api/profile/:userId', (req, res) => {
  const user = users[req.params.userId];
  if (user) {
    res.json({ userId: req.params.userId, ...user });
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

// PUT update profile
app.put('/api/profile/:userId', (req, res) => {
  const user = users[req.params.userId];
  if (user) {
    Object.assign(user, req.body);
    res.json({ message: 'Profile updated successfully.' });
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

// POST add workout
app.post('/api/profile/:userId/workouts', (req, res) => {
  const user = users[req.params.userId];
  if (user) {
    const newWorkout = { ...req.body, workoutId: `w${Date.now()}` };
    user.recentWorkouts.push(newWorkout);
    res.json({ message: 'Workout added successfully.', workoutId: newWorkout.workoutId });
  } else {
    res.status(404).json({ error: 'User not found' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
