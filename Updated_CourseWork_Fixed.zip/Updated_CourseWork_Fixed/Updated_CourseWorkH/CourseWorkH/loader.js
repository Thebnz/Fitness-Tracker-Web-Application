document.addEventListener('DOMContentLoaded', function () {

    const loader = document.createElement('div');
    loader.id = 'page-loader';
    loader.innerHTML = `<div class="spinner"></div>`;
    document.body.appendChild(loader);


    const style = document.createElement('style');
    style.textContent = `
        #page-loader {
            position: fixed;
            top: 0; left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(255, 255, 255, 0.8);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .spinner {
            border: 6px solid #ccc;
            border-top: 6px solid #000;
            border-radius: 50%;
            color:red;
            width: 40px;
            height: 40px;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);

    document.querySelectorAll('a[href$=".html"], a[href$=".htm"]').forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault(); 
            const url = this.href;


            document.getElementById('page-loader').style.display = 'flex';

            setTimeout(() => {
                window.location.href = url;
            }, 400);
        });
    });
});
