document.addEventListener("DOMContentLoaded", () => {
  const metricFields = document.getElementById("metric-fields");
  const usFields = document.getElementById("us-fields");
  const resetBtn = document.getElementById("reset");
  const result = document.getElementById("result");

  document.querySelectorAll("input[name='units']").forEach((el) =>
    el.addEventListener("change", () => {
      if (el.value === "metric") {
        metricFields.style.display = "block";
        usFields.style.display = "none";
      } else {
        metricFields.style.display = "none";
        usFields.style.display = "block";
      }
      result.innerText = "";
    })
  );

  resetBtn.addEventListener("click", () => {
    document.querySelectorAll("input[type='number']").forEach((el) => el.value = "");
    result.innerText = "";
  });

  function getBMICategory(bmi) {
    if (bmi < 16) return "Severely underweight";
    if (bmi < 17) return "Very underweight";
    if (bmi < 18.5) return "Underweight";
    if (bmi < 25) return "Normal (Healthy)";
    if (bmi < 30) return "Overweight";
    if (bmi < 35) return "Obese Class I (Moderate)";
    if (bmi < 40) return "Obese Class II (Severe)";
    return "Obese Class III (Very severe)";
  }

  document.getElementById("calculate").addEventListener("click", () => {
    const unit = document.querySelector("input[name='units']:checked").value;
    let bmi;

    if (unit === "metric") {
      const heightCm = parseFloat(document.getElementById("height-cm").value);
      const weightKg = parseFloat(document.getElementById("weight-kg").value);

      if (heightCm && weightKg) {
        const heightM = heightCm / 100;
        bmi = weightKg / (heightM * heightM);
      }
    } else {
      const feet = parseFloat(document.getElementById("height-ft").value);
      const inches = parseFloat(document.getElementById("height-in").value);
      const weightLbs = parseFloat(document.getElementById("weight-lbs").value);

      if ((feet || feet === 0) && (inches || inches === 0) && weightLbs) {
        const totalInches = (feet * 12) + inches;
        bmi = (weightLbs / (totalInches * totalInches)) * 703;
      }
    }

    if (bmi) {
      const category = getBMICategory(bmi);
      result.innerHTML = `Your BMI is <strong>${bmi.toFixed(1)}</strong> – <em>${category}</em>.`;
    } else {
      result.innerText = "Please enter valid inputs.";
    }
  });
});
