const apiUrl = '';

// Fetch data from the API
fetch(apiUrl)
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json(); // parse JSON from the response
  })
  .then(data => {
    console.log('Data received:', data); // handle the data
  })
  .catch(error => {
    console.error('Error fetching data:', error); // handle errors
  });
